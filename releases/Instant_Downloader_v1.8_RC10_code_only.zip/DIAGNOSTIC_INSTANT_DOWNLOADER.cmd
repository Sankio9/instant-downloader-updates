@echo off
setlocal
chcp 65001 >nul
title Instant Downloader - Diagnostic local
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Diagnostics.ps1"
echo.
pause
