/* Checks only an explicitly configured update manifest; never downloads/install apps. */
'use strict';
const fs=require('node:fs'),path=require('node:path');
const [cfgPath,outPath]=process.argv.slice(2);
function semver(v){const m=/^(\d+)\.(\d+)\.(\d+)(?:-rc\.(\d+))?$/.exec(String(v));if(!m)return null;return m.slice(1).map((x,i)=>i===3?(x?Number(x):Infinity):Number(x));}
function newer(a,b){const x=semver(a),y=semver(b);if(!x||!y)return false;for(let i=0;i<4;i++){if(x[i]!==y[i])return x[i]>y[i];}return false;}
async function fetchManifest(source,cfgPath){
  let json;
  if(/^https:\/\//i.test(source)){
    const controller=new AbortController();const timer=setTimeout(()=>controller.abort(),10000);
    try{
      const response=await fetch(source,{redirect:'follow',signal:controller.signal,headers:{'Accept':'application/json'}});
      if(!response.ok||!response.url.startsWith('https://'))throw Error('Manifest HTTPS invalid');
      json=await response.text();if(json.length>128000)throw Error('Manifest prea mare');
    } finally{clearTimeout(timer);}
  }else if(/^\w+:\/\//.test(source))throw Error('Manifest remote doar HTTPS');
  else json=fs.readFileSync(path.isAbsolute(source)?source:path.resolve(path.dirname(cfgPath),source),'utf8');
  const data=JSON.parse(json.replace(/^\uFEFF/,''));
  if(!semver(data.version)||!/^[a-f0-9]{64}$/i.test(String(data.sha256||''))||!['stable','rc'].includes(data.channel))throw Error('Manifest incomplet');
  return data;
}
async function go(){
  const cfg=JSON.parse(fs.readFileSync(cfgPath,'utf8').replace(/^\uFEFF/,''));
  const sources=[String(cfg.updateManifestSource||'').trim(),String(cfg.updateManifestFallback||'').trim()].filter(Boolean);
  const result={checkedAt:new Date().toISOString(),status:'unconfigured'};
  if(!sources.length)return result;
  let valid=0,found=null,failures=[];
  for(const source of [...new Set(sources)]){
    try{
      const data=await fetchManifest(source,cfgPath);valid++;
      if(cfg.updateChannel!=='rc' && (data.channel==='rc'||String(data.version).includes('-rc.')))continue;
      if(newer(data.version,cfg.version)&&(!found||newer(data.version,found.version)))
        found={version:data.version,notes:String(data.notes||'').slice(0,300),source};
    }catch(e){failures.push(String(e.message||e).slice(0,80));}
  }
  if(found)return {...result,status:'available',...found};
  if(valid)return {...result,status:'up-to-date'};
  return {...result,status:'error',message:'Ambele surse indisponibile: '+failures.join('; ').slice(0,180)};
}
if(require.main===module)(async()=>{const result=await go();fs.mkdirSync(path.dirname(outPath),{recursive:true});const t=outPath+'.tmp';fs.writeFileSync(t,JSON.stringify(result));fs.renameSync(t,outPath);})().catch(e=>{process.stderr.write(String(e));process.exitCode=1;});
module.exports={semver,newer};
