@echo off
setlocal
title Instant Downloader
powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0Instant_Downloader.ps1"
if errorlevel 1 pause
