Instant Downloader RC6
- Cronometru, indicator activitate fara date false despre freeze
- English default / Romana, preferinta salvata in config.json
- Update din aplicatie fara ZIP/manifest manual (necesita canal de release HTTPS configurat)
- Installer existent separat
