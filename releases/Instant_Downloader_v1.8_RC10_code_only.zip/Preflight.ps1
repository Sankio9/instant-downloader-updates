﻿# Uses the Windows PowerShell parser to detect syntax problems before installation.
$root=Split-Path -Parent $MyInvocation.MyCommand.Path
foreach($name in @('Install_Instant_Downloader.ps1','Instant_Downloader.ps1','Update_Instant_Downloader.ps1','Apply_Update.ps1')){
  $tokens=$null; $errors=$null
  $null=[System.Management.Automation.Language.Parser]::ParseFile((Join-Path $root $name),[ref]$tokens,[ref]$errors)
  if($errors.Count -gt 0){
    Write-Host "ERROR: $name" -ForegroundColor Red
    foreach($err in $errors){Write-Host ($err.Extent.StartLineNumber.ToString()+': '+$err.Message) -ForegroundColor Yellow}
    exit 1
  }
}
Write-Host 'Instant Downloader installer: PowerShell syntax OK.'
