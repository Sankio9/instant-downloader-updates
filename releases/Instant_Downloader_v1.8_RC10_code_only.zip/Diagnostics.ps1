﻿$ErrorActionPreference='Continue'
$root=Split-Path -Parent $MyInvocation.MyCommand.Path
Write-Host '=== INSTANT DOWNLOADER - DIAGNOSTIC LOCAL ==='
Write-Host 'Nu sunt citite sau afisate parole/cookie-uri.'
$cfgFile=Join-Path $root 'config.json'
if(-not (Test-Path -LiteralPath $cfgFile)){
  Write-Host 'Aplicatia nu este inca instalata (config.json lipseste).' -ForegroundColor Yellow
  exit 1
}
try{$cfg=Get-Content -LiteralPath $cfgFile -Raw | ConvertFrom-Json}catch{Write-Host 'Configuratie invalida.' -ForegroundColor Red;exit 2}
Write-Host ('Versiune: '+$cfg.version)
foreach($key in @('tempPath','archivePath')){
 $v=[string]$cfg.$key
 if(Test-Path -LiteralPath $v){
  $drive=[IO.Path]::GetPathRoot($v)
  try{$di=New-Object IO.DriveInfo($drive);Write-Host ($key+': DISPONIBIL ('+[Math]::Round($di.AvailableFreeSpace / 1GB,1)+' GB liberi)')}catch{Write-Host ($key+': ACCES NECUNOSCUT')}
 }else{Write-Host ($key+': LIPSESTE')}
}
$node=[string]$cfg.nodePath
if(Test-Path -LiteralPath $node){try{Write-Host ('Node: '+(& $node --version))}catch{Write-Host 'Node: eroare la pornire'}}else{Write-Host 'Node: nu a fost gasit'}
$deps=Join-Path $root 'node_modules/skool-downloader/src/index.ts'
Write-Host ('Pachete Node: '+$(if(Test-Path -LiteralPath $deps){'OK'}else{'LIPSA'}))
$browser=Join-Path ([string]$cfg.tempPath) '_browsers'
Write-Host ('Browser Playwright: '+$(if((Test-Path -LiteralPath $browser) -and @(Get-ChildItem -LiteralPath $browser -Directory -ErrorAction SilentlyContinue).Count -gt 0){'PREZENT'}else{'NEDETECTAT'}))
$ff=Join-Path $root 'node_modules/ffmpeg-static/ffmpeg.exe'
Write-Host ('FFmpeg local: '+$(if(Test-Path -LiteralPath $ff){'PREZENT'}else{'NEDETECTAT; poate fi in PATH'}))
$dl=Join-Path ([string]$cfg.tempPath) '_cache/bin/yt-dlp.exe'
Write-Host ('yt-dlp: '+$(if(Test-Path -LiteralPath $dl){'PREZENT'}else{'NEDETECTAT'}))
$auth=Join-Path $root '.auth/storage_state.json'
Write-Host ('Sesiunea Skool: '+$(if(Test-Path -LiteralPath $auth){'FISIER PREZENT (validitatea nu este verificata)'}else{'NEAUTENTIFICAT'}))
Write-Host '=== SFARSIT DIAGNOSTIC ==='
