/* Instant Downloader 1.4, integration shim for skool-downloader@1.0.0.
 * Reuses existing v1.3 modifications; never overwrites session, metadata or video.
 * Refuses unexpected vendor source; creates immutable original backups.
 */
'use strict';
const fs = require('node:fs');
const path = require('node:path');
const dir = path.join(__dirname, 'node_modules', 'skool-downloader', 'src');
const plans = [];
const intro = 'SKOOL_MANAGER_1_3';
const v14 = 'SKOOL_MANAGER_1_4';

function plan(fileName, alter) {
  const file=path.join(dir,fileName);
  if(!fs.existsSync(file))throw new Error('The pinned package source is missing: '+fileName);
  const orig=fs.readFileSync(file,'utf8');
  const next=alter(orig);
  if(orig!==next)plans.push({file,orig,next});
}
function replaceOnce(contents,search,replace,fileName){
  if(contents.split(search).length!==2)
    throw new Error('Unexpected vendor source in '+fileName+'. No changes were made.');
  return contents.replace(search,replace);
}
plan('downloader.ts',s=>{
  if(s.includes(intro))return s;
  s=replaceOnce(s,'async downloadVideo(url: string, outputDir: string, filename: string) {',
    'async downloadVideo(url: string, outputDir: string, filename: string, onProgress?: (data: any) => void) { // '+intro,'downloader.ts');
  const eventHandler=String.raw`await new Promise<void>((resolve,reject) => {
    let settled=false;
    const emitter=this.ytDlp!.exec(args);
    emitter.on('progress',(p:any)=>{
      if(!onProgress)return;
      const percent=Number.parseFloat(String(p?.percent ?? '').replace('%','').replace(',','.'));
      if(Number.isFinite(percent))onProgress({percent,speed:String(p?.currentSpeed ?? ''),eta:String(p?.eta ?? '')});
    });
    emitter.on('error',(error:Error)=>{if(!settled){settled=true;reject(error);}});
    emitter.on('close',(code:number)=>{if(settled)return;settled=true;
      if(typeof code==='number' && code!==0)reject(new Error('yt-dlp exit code '+code));
      else resolve();
    });
  });`;
  return replaceOnce(s,'await this.ytDlp!.execPromise(args);',eventHandler,'downloader.ts');
});
plan('index.ts',s=>{
  if(!s.includes(intro)) {
    const callback=String.raw`await downloader.downloadVideo(lessonData.videoLink, lessonDir, 'video', (p: any) => {
      process.stdout.write('@@SKOOL@@' + JSON.stringify({type:'progress',id:mInfo.mIndex+'.'+lIndex,title:lesson.title,percent:p.percent,speed:p.speed,eta:p.eta}) + '\n');
    }); // SKOOL_MANAGER_1_3`;
    s=replaceOnce(s,"await downloader.downloadVideo(lessonData.videoLink, lessonDir, 'video');",callback,'index.ts');
  }
  if(!s.includes(v14)){
    const warn='logger.warn(`    ⚠️ Failed to download video for ${lesson.title}`);';
    const replacement=String.raw`process.stdout.write('@@SKOOL@@' + JSON.stringify({type:'failed-video',id:mInfo.mIndex+'.'+lIndex,title:lesson.title}) + '\n'); // SKOOL_MANAGER_1_4
    `+warn;
    s=replaceOnce(s,warn,replacement,'index.ts');
  }
  return s;
});
// Only apply changes if both vendor files were recognized first.
for(const p of plans){
  const backup=p.file+'.before-manager-v1_4';
  if(!fs.existsSync(backup))fs.writeFileSync(backup,p.orig,{flag:'wx'});
  const temp=p.file+'.manager-tmp';
  fs.writeFileSync(temp,p.next);
  fs.renameSync(temp,p.file);
  console.log('Updated: '+path.basename(p.file));
}
console.log('Skool progress + video error reporting ready.');
