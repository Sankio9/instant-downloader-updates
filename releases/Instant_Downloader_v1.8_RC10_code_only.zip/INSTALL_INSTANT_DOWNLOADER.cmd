@echo off
setlocal
chcp 65001 >nul
title Instant Downloader - Instalare Windows
set "ROOT=%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%ROOT%Preflight.ps1"
if errorlevel 1 (
 echo.
 echo Verificarea installerului nu a trecut. Trimiteti doar mesajul de eroare, fara date personale.
 pause
 exit /b 1
)
powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -File "%ROOT%Install_Instant_Downloader.ps1"
if errorlevel 1 (
 echo.
 echo Instalarea nu s-a finalizat. Verifica fereastra si jurnalul.
 pause
)
