'use strict';
const fs=require('node:fs'),path=require('node:path'),os=require('node:os'),assert=require('node:assert/strict'),{spawnSync}=require('node:child_process');
const {parseSelection,filterModuleTasks,runSelectedTasks}=require('./selection.cjs');
const {newer}=require('./check_update_notice.cjs');
(async()=>{
 assert.deepEqual(parseSelection(JSON.stringify({level:'modules',keys:['1','3','3']})),{level:'modules',keys:['1','3']});
 assert.throws(()=>parseSelection(JSON.stringify({level:'modules',keys:[]})));
 const fake=[1,2,3,4,5,6].map((n)=>({title:`[${n%3+1}.${n}] lesson`,run:async()=>{}}));
 assert.equal(filterModuleTasks(fake,{level:'modules',keys:['1']}).length,2);
 let active=0,peak=0,done=0;
 const tasks=Array.from({length:12},(_,i)=>({title:`[${i%3+1}.${i+1}] L`,run:async()=>{active++;peak=Math.max(peak,active);await new Promise(r=>setTimeout(r,6));done++;active--;}}));
 await runSelectedTasks(tasks,4,{level:'modules',keys:['1','2']});
 assert.equal(done,8);assert.equal(peak,4);
 assert.equal(newer('1.6.0-rc.1','1.5.0-rc.1'),true);
 assert.equal(newer('1.6.0','1.6.0-rc.9'),true);
 assert.equal(newer('1.5.9','1.6.0-rc.1'),false);
 const root=fs.mkdtempSync(path.join(os.tmpdir(),'skool16-'));
 try{
  const manifest=path.join(root,'manifest.json'),conf=path.join(root,'config.json'),out=path.join(root,'notice.json');
  fs.writeFileSync(manifest,JSON.stringify({version:'1.6.0-rc.2',channel:'rc',sha256:'a'.repeat(64),package_path:'fake.zip',notes:'Test'}));
  fs.writeFileSync(conf,JSON.stringify({version:'1.6.0-rc.1',updateChannel:'rc',updateManifestSource:manifest}));
  let p=spawnSync(process.execPath,[path.join(__dirname,'check_update_notice.cjs'),conf,out],{encoding:'utf8'});
  assert.equal(p.status,0,p.stderr);
  assert.equal(JSON.parse(fs.readFileSync(out,'utf8')).status,'available');
  fs.writeFileSync(conf,JSON.stringify({version:'1.6.0-rc.1',updateChannel:'stable',updateManifestSource:manifest}));
  p=spawnSync(process.execPath,[path.join(__dirname,'check_update_notice.cjs'),conf,out],{encoding:'utf8'});
  assert.equal(JSON.parse(fs.readFileSync(out,'utf8')).status,'up-to-date');
 }finally{fs.rmSync(root,{recursive:true,force:true});}
 const bridge=fs.readFileSync(path.join(__dirname,'bridge.mjs'),'utf8');
 assert.match(bridge,/scanCatalog/);assert.match(bridge,/selectedRunner/);
 const gui=fs.readFileSync(path.join(__dirname,'Instant_Downloader.ps1'),'utf8');
 assert.match(gui,/ShowSelectionDialog/);assert.match(gui,/RecordStatus/);assert.match(gui,/ShowBalloonTip/);
 const updates=fs.readFileSync(path.join(__dirname,'Update_Instant_Downloader.ps1'),'utf8');
 for(const f of ['check_update_notice.cjs','selection.cjs']) assert.ok(updates.includes(f));
 console.log('PASS: new selected-subgroup runner, concurrency 4, update alerts, stable/RC channels and UI wiring');
})().catch(e=>{console.error(e);process.exitCode=1;});
