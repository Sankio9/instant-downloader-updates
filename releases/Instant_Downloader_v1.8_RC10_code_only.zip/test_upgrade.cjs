'use strict';
const fs=require('node:fs'),os=require('node:os'),path=require('node:path'),cp=require('node:child_process'),assert=require('node:assert/strict');
const tmp=fs.mkdtempSync(path.join(os.tmpdir(),'skool-upgrade-'));
try{
 const dir=path.join(tmp,'node_modules/skool-downloader/src');fs.mkdirSync(dir,{recursive:true});
 fs.copyFileSync(path.join(__dirname,'patch_progress.cjs'),path.join(tmp,'patch_progress.cjs'));
 fs.writeFileSync(path.join(dir,'downloader.ts'),`async downloadVideo(url: string, outputDir: string, filename: string) {\n  await this.ytDlp!.execPromise(args);\n}`);
 fs.writeFileSync(path.join(dir,'index.ts'),"async function fn(){\n  await downloader.downloadVideo(lessonData.videoLink, lessonDir, 'video');\n  logger.warn(`    ⚠️ Failed to download video for ${lesson.title}`);\n}");
 const run=()=>{const r=cp.spawnSync(process.execPath,[path.join(tmp,'patch_progress.cjs')],{encoding:'utf8'});assert.equal(r.status,0,r.stderr+r.stdout);};
 run();
 let data=fs.readFileSync(path.join(dir,'index.ts'),'utf8');assert.ok(data.includes('SKOOL_MANAGER_1_4'));assert.ok(data.includes('SKOOL_MANAGER_1_3'));
 data=data.replace(/process\.stdout\.write\('@@SKOOL@@' \+ JSON\.stringify\(\{type:'failed-video'.*?SKOOL_MANAGER_1_4\n    /,'');
 fs.writeFileSync(path.join(dir,'index.ts'),data);
 run();
 const upgraded=fs.readFileSync(path.join(dir,'index.ts'),'utf8');
 assert.ok(upgraded.includes('SKOOL_MANAGER_1_4'));
 assert.equal(upgraded.split('SKOOL_MANAGER_1_4').length,2);
 run();assert.equal(fs.readFileSync(path.join(dir,'index.ts'),'utf8'),upgraded);
 console.log('PASS: upgrade from a v1.3 patched dependency adds v1.4 error reporting once');
}catch(e){console.error(e);process.exitCode=1;}finally{fs.rmSync(tmp,{recursive:true,force:true});}
