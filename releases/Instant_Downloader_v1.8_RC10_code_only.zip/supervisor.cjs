/* Process supervisor: keeps logs off the UI thread; all subprocesses stay local. */
'use strict';
const fs = require('node:fs');
const path = require('node:path');
const {spawn} = require('node:child_process');
const jobPath = process.argv[2];
if (!jobPath) process.exit(2);
const job = JSON.parse(fs.readFileSync(jobPath, 'utf8'));
const root = __dirname;
const stream = fs.createWriteStream(job.logPath, { flags: 'a' });
let child;
try { child = spawn(process.execPath, ['--import', 'tsx', path.join(root, 'bridge.mjs'), job.mode, job.url || '', job.output || ''], {
  cwd: root,
  env: {...process.env,
    TEMP: job.temp, TMP: job.temp,
    TMPDIR: job.temp,
    NPM_CONFIG_CACHE: path.join(job.tempRoot, '_npm-cache'),
    PLAYWRIGHT_BROWSERS_PATH: path.join(job.tempRoot,'_browsers'),
    SKOOL_DOWNLOADER_CACHE_DIR: path.join(job.tempRoot, '_cache'),
    FORCE_COLOR:'0', NO_COLOR:'1',
    SKOOL_SELECTION_JSON: JSON.stringify(job.selection || {level:'all',keys:[]}),
  },
  shell:false, windowsHide:true,
  stdio:['ignore','pipe','pipe']
}); }catch(error){
  stream.write('@@SKOOL@@'+JSON.stringify({type:'fatal',message:'Nu pot porni procesul Node: '+String(error.message||error)})+'\n');
  stream.end();process.exit(1);
}
child.stdout.pipe(stream, {end:false});
child.stderr.pipe(stream, {end:false});
child.on('error', e=> {stream.write('ERROR: '+e.message+'\n'); stream.end();process.exitCode=1;});
child.on('close', code=>{stream.write('@@SKOOL@@'+JSON.stringify({type:'exit',code})+'\n');stream.end();process.exitCode=code || 0;});
