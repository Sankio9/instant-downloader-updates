'use strict';
const fs=require('fs'),os=require('os'),path=require('path'),assert=require('node:assert/strict');
const {audit}=require('./audit_archive.cjs');
const t=fs.mkdtempSync(path.join(os.tmpdir(),'skool-audit-'));
try{
 const root=path.join(t,'SkoolArchive'),course=path.join(root,'Comunitate','Curs'),one=path.join(course,'01-Text Only'),two=path.join(course,'02-Video'),three=path.join(course,'03-Broken');
 for(const p of [one,two,three])fs.mkdirSync(p,{recursive:true});
 fs.writeFileSync(path.join(one,'lesson.json'),JSON.stringify({title:'Text, linkuri si PDF',hasVideo:false,resourcesCount:1}));
 fs.mkdirSync(path.join(one,'resources'));fs.writeFileSync(path.join(one,'resources','ghid.pdf'),'dummy');
 fs.writeFileSync(path.join(one,'index.html'),'<h1>Text</h1><a href="https://example.org">Link extern</a><a href="resources/ghid.pdf">PDF</a>');
 fs.writeFileSync(path.join(two,'lesson.json'),JSON.stringify({title:'Video complet',hasVideo:true,resourcesCount:0}));
 fs.writeFileSync(path.join(two,'index.html'),'<video src="video.mp4"></video>');fs.writeFileSync(path.join(two,'video.mp4'),'sample nonempty');
 fs.writeFileSync(path.join(three,'lesson.json'),JSON.stringify({title:'Fisier lipsa',hasVideo:false,resourcesCount:0}));
 fs.writeFileSync(path.join(three,'index.html'),'<img src="assets/lipsa.png">');
 const v=audit(root);assert.equal(v.lessons,3);assert.equal(v.complete,2);assert.equal(v.incomplete,1);assert.equal(v.invalid,0);
 fs.writeFileSync(path.join(three,'index.html'),'<h1>corectat</h1>');assert.equal(audit(root).complete,3);
 console.log('PASS: audit text-only + PDF + external link; video; detect broken asset; re-audit');
}finally{fs.rmSync(t,{recursive:true,force:true});}
