/* Offline archive audit; never uploads data, never follows external links. */
'use strict';
const fs=require('node:fs');
const path=require('node:path');
const excluded=new Set(['node_modules','.auth','_temp','_cache','_npm-cache','_browsers','_history','_jobs','_updates']);
function safeRef(folder,reference){
  try{
    const p=decodeURIComponent(reference.split('?')[0].split('#')[0]);
    if(!/^(resources|assets)\//.test(p))return null;
    const resolved=path.resolve(folder,p);if(!resolved.startsWith(path.resolve(folder)+path.sep))return null;
    return resolved;
  }catch{return null;}
}
function audit(root){
  const summary={lessons:0,complete:0,incomplete:0,invalid:0,issues:[]};
  if(!root||!fs.existsSync(root))throw Error('Arhiva nu exista');
  const stack=[path.resolve(root)];
  while(stack.length){
    const folder=stack.pop();
    const entries=fs.readdirSync(folder,{withFileTypes:true});
    for(const e of entries){if(e.isDirectory()&&!excluded.has(e.name)&&!e.name.startsWith('_')&&!e.isSymbolicLink())stack.push(path.join(folder,e.name));}
    const metadata=path.join(folder,'lesson.json');if(!fs.existsSync(metadata))continue;
    summary.lessons++;
    const problems=[];
    try{
      const meta=JSON.parse(fs.readFileSync(metadata,'utf8'));
      const htmlPath=path.join(folder,'index.html');
      if(!fs.existsSync(htmlPath)||fs.statSync(htmlPath).size===0)problems.push('Lipseste pagina index.html');
      if(meta.hasVideo && (!fs.existsSync(path.join(folder,'video.mp4'))||fs.statSync(path.join(folder,'video.mp4')).size===0))problems.push('Lipseste video.mp4');
      const resourceDir=path.join(folder,'resources');
      const resourceFiles=fs.existsSync(resourceDir)?fs.readdirSync(resourceDir,{withFileTypes:true}).filter(x=>x.isFile()&&fs.statSync(path.join(resourceDir,x.name)).size>0).length:0;
      if(Number(meta.resourcesCount||0)>resourceFiles)problems.push('Lipsesc atasamente din resources/');
      if(fs.existsSync(htmlPath)){
        const html=fs.readFileSync(htmlPath,'utf8');
        for(const match of html.matchAll(/(?:src|href)\s*=\s*['"]((?:resources|assets)\/[^'"<>]+)['"]/gi)){
          const target=safeRef(folder,match[1]);
          if(!target||!fs.existsSync(target)||fs.statSync(target).size===0)problems.push('Fisier local lipsa: '+match[1].slice(0,120));
        }
      }
      if(problems.length){summary.incomplete++;summary.issues.push({id:meta.moduleIndex!=null&&meta.lessonIndex!=null?String(meta.moduleIndex)+'.'+String(meta.lessonIndex):folder,lesson:String(meta.title||path.basename(folder)),folder,problems});}
      else summary.complete++;
    }catch(e){summary.invalid++;summary.issues.push({lesson:path.basename(folder),folder,problems:['Metadata/HTML invalid: '+String(e.message||e).slice(0,100)]});}
  }
  return summary;
}
if(require.main===module){try{const x=audit(process.argv[2]);process.stdout.write('@@SKOOL@@'+JSON.stringify({type:'audit',...x})+'\n');process.exitCode=x.incomplete+x.invalid?2:0;}catch(e){process.stderr.write(String(e)+'\n');process.exitCode=1;}}
module.exports={audit};
