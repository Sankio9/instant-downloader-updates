/* Reusable selection and scheduling core. No Skool account access here. */
'use strict';
function parseSelection(raw){
  if(!raw)return {level:'all',keys:[]};
  let obj;try{obj=JSON.parse(raw);}catch{throw Error('Selectie invalida');}
  if(!obj || !['courses','modules','all'].includes(obj.level) || !Array.isArray(obj.keys)) throw Error('Selectie invalida');
  const keys=[...new Set(obj.keys.map(v=>String(v)).filter(v=>/^[a-zA-Z0-9_.-]{1,128}$/.test(v)))];
  if(obj.level!=='all' && keys.length===0)throw Error('Selecteaza cel putin un element.');
  return {level:obj.level,keys};
}
function filterModuleTasks(tasks,selection){
  if(selection.level!=='modules')return tasks;
  const allowed=new Set(selection.keys.map(Number));
  return tasks.filter(t=>{const m=/^\[(\d+)\.(\d+)\]/.exec(t.title);return m&&allowed.has(Number(m[1]));});
}
async function runSelectedTasks(tasks, concurrency, selection, notify=()=>{}){
  const work=filterModuleTasks(tasks,selection);
  notify({type:'info',message:`Procesam ${work.length} lectii selectate din ${tasks.length}.`});
  let cursor=0;
  await Promise.all(Array.from({length:Math.min(Math.max(1,concurrency),4,work.length)},async()=>{
    while(cursor<work.length){const task=work[cursor++];await task.run();}
  }));
}
module.exports={parseSelection,filterModuleTasks,runSelectedTasks};
